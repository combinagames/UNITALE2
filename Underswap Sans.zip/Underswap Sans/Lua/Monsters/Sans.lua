-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"Esta pensando en su \nlugar de reunion \ncontigo.", "El es lindo y divertido.", "Y si tu lo matas \nvas a tener \nun mal rato."}
commands = {"ADMIRAR", "HABLAR", "FELICITAR"}
randomdialogue = {"[font:sans]MWEH HEH HEH.", "[font:sans]Vamos\nmuestrame \nlo que tienes!", "[font:sans]Quieres pasar\nel rato mas tarde?"}

sprite = "poseur" --Always PNG. Extension is added automatically.
name = "Sans"
hp = 350
atk = 10
def = 0
check = "Dice 'MWEH HEH HEH' mucho."
dialogbubble = "rightwide" -- See documentation for what bubbles you have available.
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack 
        canspare = false
    end
 end
 
function HandleCustomCommand(command)
    if command == "ADMIRAR" then
        BattleDialog({"Le dices a Sans que su \n'cuerpo de batalla'\nes super genial y lo admiras!"})
        currentdialogue = {"[font:sans]Gracias humano,\nyo y mi \nhermano lo hicimos."}
        elseif command == "HABLAR" then
        BattleDialog({"Le dices a Sans \nsobre tu \ntipo favorito de taco"})
        currentdialogue = {"[font:sans]Bueno,\nte gustan los \nTACOS tambien!"}
        elseif command == "FELICITAR" then
        BattleDialog({"Le dices a Sans\nque su ataque es SANSacional"})
        currentdialogue = {"[font:sans]Gracias humano pero \nvamos a centrarnos en \nla pelea y luego \nte capturare \npodemos pasar el rato!"}
        canspare = true
    end
end

function OnDeath()
Audio.Stop()
currentdialogue = {"[noskip][font:sans][effect:shake]P-Papyrus...", "[noskip][font:sans][effect:shake]...ayudame...", "[noskip][font:sans][effect:shake]humano...", "[noskip][font:sans][effect:shake]yo... me ha pasado...\ntal vez... \npodriamos...\n... ser AMIGOS...", "[noskip][font:sans][effect:shake]...pero...no...\nno hay que preocuparnos!\nPapyrus arreglara esto!", "[func:Kill]"}
State("ENEMYDIALOGUE")
end

