bullets = {}

start = Time.time
gforcemult = 1
timer = 0

Arena.ResizeImmediate(350, 350)
Player.MoveTo(0,0,false)
cooldown = 0
setupWave = 1

function lerp(a,b,t)
	return (1-t)*a + t*b
end

function makeBullet(x, y, goalheight)
	local b = CreateProjectile("pellet", x, y)
	b.SetVar("goalHeight",goalheight)
	b.SetVar("startHeight",y)
	b.SetVar("createTime",curr)
	b.SetVar("vx",0)
	b.SetVar("vy",0)
	b.SetVar("ax",0)
	b.SetVar("ay",0)
	table.insert(bullets, b)
end

function SpawnNew()
	if cooldown <= 0 then
		cooldown = 0.2
		
		local goalHeight = (Arena.height/2) - (setupWave)*Arena.height/8
		local goalHeight2 =  - goalHeight
		local width = Arena.width/2
		for i= -width*0.8,width*0.8,width*0.2 do
			makeBullet(i, Arena.height/2, goalHeight)
		end
		if(goalHeight != goalHeight2) then
			for i= -width*0.8,width*0.8,width*0.2 do
				makeBullet(i, -Arena.height/2, goalHeight2)
			end
		end
		setupWave = setupWave + 1
	end
	cooldown = cooldown - Time.dt
end

function MoveDown()
	for i,b in pairs(bullets) do
		local created = b.GetVar("createTime")
		local goal = b.GetVar("goalHeight")
		local startH = b.GetVar("startHeight")
		local diff = curr - created
		if (diff) <= 1 then
		
			local t = 1 - (1-diff)*(1-diff)
			b.MoveTo(b.x,lerp(startH, goal,t))
		end
	end
end

function Flash()
	local power = math.random()*30 + 40
	local angle = math.random()*math.pi*2
	local primaryX = power * math.cos(angle)
	local primaryY = power * math.sin(angle)
	
	for i,b in pairs(bullets) do
		b.SetVar("vx",primaryX + math.random()*10-5)
		b.SetVar("vy",primaryY + math.random()*10-5)
		b.SetVar("ax", math.random()*10-5)
		b.SetVar("ay", math.random()*10-5)
	end
end

function Physics()
	for i,b in pairs(bullets) do
		local dt = Time.dt
		local vx = b.GetVar("vx")
		local vy = b.GetVar("vy")
		local ax = b.GetVar("ax")
		local ay = b.GetVar("ay")
		b.MoveTo(b.x+vx*dt,b.y+vy*dt)
		b.SetVar("vx",vx+ax*dt)
		b.SetVar("vy",vy+ay*dt)
	end
end

flashed = false
function Update()
	curr = Time.time - start
	if curr < 0.75 then
		SpawnNew()
	end
	if curr < 1.75 then
		MoveDown()
	end
	if curr > 1.75 and flashed == false then
		Flash()
		flashed = true
	end
	if curr > 1.75 then
		Physics()
	end
end
 
function OnHit(bullet)
	Player.Hurt(2,0.2)
	Audio.PlaySound('hit')
end