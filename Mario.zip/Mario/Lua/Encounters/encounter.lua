-- A basic encounter script skeleton you can copy and modify for your own creations.

-- music = "shine_on_you_crazy_diamond" --Always OGG. Extension is added automatically. Remove the first two lines for custom music.
music = "Mario fight"
encountertext = "What did you do to deserve this?" --Modify as necessary. It will only be read out in the action select screen.
wavetimer = 5.0
arenasize = {155, 155}

enemies = {
"poseur"
}
canspare = false

enemypositions = {
{0, 0}
}

def = 10
attacknum = 0

-- A custom list with attacks to choose from. Actual selection happens in EnemyDialogueEnding(). Put here in case you want to use it.
possible_attacks = {"rippleeffect", "bullettest_touhou", "bullettest_bouncy", "bullettest_chaserorb", "bullettest_blackhole"}

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
    
end

function EnemyDialogueEnding()
    attacknum = attacknum + 1
    if attacknum == 1 then
    nextwaves = {"rippleeffect"}
    elseif attacknum == 2 then
    nextwaves = {"bullettest_blackhole"}
    elseif attacknum == 3 then
    nextwaves = {"bullettest_touhou"}
    elseif attacknum == 4 then
    nextwaves = {"bullettest_bouncy"}
    elseif attacknum == 5 then
    nextwaves = {"bullettest_blackhole"}
    elseif attacknum == 6 then
    nextwaves = {"rippleeffect"}
    elseif attacknum == 7 then
    nextwaves = {"bullettest_blackhole"}
    elseif attacknum == 8 then
    nextwaves = {"bullettest_touhou"}
    elseif attacknum == 9 then
    nextwaves = {"bullettest_bouncy"}
    elseif attacknum == 10 then
    nextwaves = {"bullettest_blackhole"}
    def = def - 10000010
    attacknum = 0
    elseif def == -10000001 then
    music = "GAME OVER"
    end
    if attacknum == 5 then
    canspare = true
    end
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end