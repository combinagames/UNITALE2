-- A basic monster script skeleton you can copy and modify for your own creations.
currentdialogue = {"[skip][font:sans][func:SetSprite,poseur]Hey you!", "[skip][font:sans]You come \nhere\nand you \ndont \nsay hello?", "[font:sans]What a\nbad \nperson"}
randomdialogue = {"[font:sans]..."}
comments = {"Just atack"}
commands = {"Talk"}

sprite = "poseur" --Always PNG. Extension is added automatically.
name = "Mario"
hp = 500
atk = 1
def = 10
check = "What did you do to get this?."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true

SetGlobal("fightcounter", 0)
-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        
    else
        SetGlobal("fightcounter", GetGlobal("fightcounter") + 1)
        SetSprite("poseur2")
        def = def -1
        if def == 0 then
            canspare = true
            dialogbubble = "rightwide"
            currentdialogue = {"[font:sans]We can be friends...", "[font:sans]But please", "[font:sans]Stop atacking me"}
            def = def - 10000000
            comments = {"Mario is spearing you"}
        end
        if def == 8 then
            dialogbubble = "rightwide"
            currentdialogue = ("[func:SetSprite,poseur][font:sans]So you want to\nkill me?")
        elseif def == 7 then
            dialogbubble = "right"
            currentdialogue = ("[func:SetSprite,poseur][font:sans]...")
        elseif def == 6 then 
            dialogbubble = "rightwide"
            currentdialogue = ("[func:SetSprite,poseur][font:sans]Wow, just Wow")
        elseif def == 5 then
            dialogbubble = "rightwide"
            currentdialogue = ("[func:SetSprite,poseur][font:sans]I know one thing")
        elseif def == 4 then
            dialogbubble = "rightwide"
            currentdialogue = ("[func:SetSprite,poseur][font:sans]Toads want to help")
        elseif def == 3 then
            dialogbubble = "rightwide"
            currentdialogue = ("[func:SetSprite,poseur][font:sans]But you")
        elseif def == 2 then 
            dialogbubble = "rightwide"
            currentdialogue = ("[func:SetSprite,poseur][font:sans]You are not like \nother toads")
        elseif def == 1 then
            dialogbubble = "right"
            currentdialogue = ("[func:SetSprite,poseur][font:sans]...")
        end
    end
    function OnDeath()
        dialogbubble = "rightwide"
        Audio.Stop("Mario fight")
        Audio.LoadFile("GAME OVER")
        currentdialogue = {"[func:SetSprite,Mario dead][noskip][font:sans][effect:shake]So...", "[noskip][font:sans][effect:shake]...I guess...", "[noskip][font:sans][effect:shake]You are stronger\nthan me", "[noskip][font:sans][effect:shake]Y-y-you", "[func:SetSprite,poseur3][noskip][font:sans][effect:shake]...MURDER", "[func:Kill]"}
        Audio.Play("GAME OVER")
        State("ENEMYDIALOGUE")
       end
end