-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"Tu hiciste una linea pacifista, \ny ahora lo quieres matar"}
commands = {"Amenazar"}
randomdialogue = {"MORIRAS \nEN \nLAS \nSOMBRAS"}

sprite = "poseur" --Always PNG. Extension is added automatically.
name = "Cyclops NEO"
hp = 200
atk = 5
def = 1
check = "Just kill him, is patetic."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        
    else
        -- player did actually attack
    end
end